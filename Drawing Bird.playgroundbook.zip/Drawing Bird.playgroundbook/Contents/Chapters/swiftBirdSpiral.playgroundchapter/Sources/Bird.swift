import SpriteKit

public protocol BirdProtocol {
    init(scene: SKScene, trailWidth: CGFloat, color : UIColor)
    init(scene: SKScene)
    
    var color: UIColor {get set}
    var bird: SKSpriteNode {get}
    var currentTrailwidth: CGFloat {get}
    var rotation: CGFloat {set get}
    var position: CGPoint {set get}
    var isHidden : Bool {get set}
    var useDraw : Bool {get set}
    
    mutating func forward(_ length: CGFloat)
    func left(_ angle: CGFloat)
    func right(_ angle: CGFloat)
    func set(trailwidth: CGFloat)
    func toggleTrail()
    func draw(_ i: Int)
    
}

public class Bird: BirdProtocol {
    private var radConst : CGFloat
    private var currentScene: SKScene
    public var bird: SKSpriteNode
    private var positions: [CGPoint]
    public var currentTrailwidth: CGFloat
    public var useDraw: Bool
    public var color: UIColor
    private var trail: Bool
    private var lines : [SKNode]
    private var rotations: [CGFloat]
    public var rotation: CGFloat {
        didSet{
            
            bird.zRotation = rotation.truncatingRemainder(dividingBy: 360)
            
        }
    }
    public var position: CGPoint {
        didSet {
            
            bird.position = self.position
            positions.append(self.position)
        }
    }
    public var isHidden: Bool {
        didSet {
            
            bird.isHidden = isHidden
            
        }
    }
    
    public required init(scene: SKScene, trailWidth: CGFloat, color : UIColor) {
        radConst = (CGFloat.pi / 180)
        positions = []
        currentTrailwidth = trailWidth
        currentScene = scene
        self.color = color
        trail = true
        rotation = 0.0
        position = CGPoint(x: 0, y: 0)
        isHidden = false
        lines = []
        rotations = []
        useDraw = false
        
        
        let size = currentScene.frame.size
        let w = (size.width + size.height) * 0.02
        
        let sizeScal = CGSize(width: w, height: w)
        bird = SKSpriteNode(color: self.color, size: sizeScal)
        
        initialiserBird(bird)
        
    }
    
    public required init(scene: SKScene) {
        radConst = (CGFloat.pi / 180)
        positions = []
        currentTrailwidth = 2.0
        currentScene = scene
        self.color = .white
        trail = true
        rotation = 0.0
        position = CGPoint(x: 0, y: 0)
        isHidden = false
        lines = []
        rotations = []
        useDraw = false
        
        let size = currentScene.frame.size
        let w = (size.width + size.height) * 0.02
        
        let sizeScal = CGSize(width: w, height: w)
        bird = SKSpriteNode(color: self.color, size: sizeScal)
        
        initialiserBird(bird)
    }
    
    
    func initialiserBird(_ scene: SKSpriteNode) {
        // Set the birds texture to a swiftbird, its position to (0,0) and add it to the scene.
        bird.color = self.color
        if let textur = UIImage(named: "swiftIcon") {
            let texture = SKTexture(image: textur)
            bird.texture = texture
            bird.colorBlendFactor = 1
        }
        
        bird.position = position
        
        
        currentScene.addChild(bird)
        
        positions.append(position)

    }
    
    
    public func forward(_ length: CGFloat) {
        // Get angle and length and translate it in to coordinates
        //using the Oversett(vinkel:, lengde:) method,
        //then draw a line to that position
        
        let vinkel = rotation.truncatingRemainder(dividingBy: 360)
        
        let pos = Oversett(vinkel: vinkel, lengde: length)
        let lastpos = bird.position
        
        let x = lastpos.x + pos.x
        let y = lastpos.y + pos.y
        
        let birdpos = CGPoint(x: x , y: y)
        
        position = birdpos
        positions.append(birdpos)
        //rotation = rotation + vinkel
        rotations.append(rotation)
        
        let lpos0 = positions[positions.count-1]
        let lpos1 = lastpos
        
        if trail { Linje(lpos1, lpos0, self.color) }
        
    }
    
    public func set(trailwidth: CGFloat) {
        self.currentTrailwidth = trailwidth
    }
    
    public func toggleTrail() {
        trail = !trail
    }
    
    
    private func Oversett(vinkel: CGFloat, lengde: CGFloat) -> CGPoint {
        // Translates length and an angle to coordinats
        //using trigonometric functions.
        
        let b = sin(vinkel * radConst) * lengde
        let a = cos(vinkel * radConst) * lengde
        
        let Koordinat = CGPoint(x: a, y: b)
        
        return Koordinat
        
    }
    
    public func left(_ angle: CGFloat) {
        
        self.rotation = (rotation + angle).truncatingRemainder(dividingBy: 360)
    }
    
    public func right(_ angle: CGFloat) {
        
        self.rotation = (rotation - angle).truncatingRemainder(dividingBy: 360)
    }
    
    func Linje(_ point1: CGPoint,_ point2: CGPoint,_ color: UIColor) {
        let liine = SKShapeNode()
        liine.lineWidth = currentTrailwidth
        
        let paath = CGMutablePath()
        paath.move(to: point1)
        paath.addLine(to: point2)
        liine.path = paath
        
        liine.strokeColor = color
        bird.color = self.color
        
        if !useDraw {
            currentScene.addChild(liine)
        }else {
            lines.append(liine)
        }
    }
    
    public func draw(_ i: Int) {
        
        if useDraw && i < lines.count && (i + 3) < positions.count{
            let line = lines[i]
            currentScene.addChild(line)
            bird.position = positions[i*2+3]
            rotation = rotations[i] * radConst
            print(bird.zRotation)
            
            
        }
        
    }
    
    

    
}
