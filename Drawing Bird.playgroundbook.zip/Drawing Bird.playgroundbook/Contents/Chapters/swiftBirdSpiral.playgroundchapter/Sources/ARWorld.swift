import SpriteKit
import SceneKit
import UIKit
import ARKit

@available(iOSApplicationExtension 11.0, *)
public protocol ARBirdWorldProtocol {
    init(didDetectSurface: @escaping (_ bird: Bird) -> Void)
    var sceneView: ARSCNView {get}
    var bird : Bird {get}
}

@available(iOSApplicationExtension 11.0, *)
public class ARBirdWorld : UIView, ARSCNViewDelegate, ARBirdWorldProtocol  {
    
    public var sceneView: ARSCNView
    public var bird: Bird
    var timer : Timer
    var detectedSurface: (_ bird: Bird) -> Void
    var hasFoundSurface: Bool
    
    required public init(didDetectSurface: @escaping (_ bird: Bird) -> Void) {
        let frame = CGRect(x: 0, y: 0, width: 600, height: 800)
        sceneView = ARSCNView(frame: frame)
        sceneView.scene = SCNScene()
        timer = Timer()
        hasFoundSurface = false
        
        bird = Bird(scene: SKScene())
        
        self.detectedSurface = didDetectSurface
        
        super.init(frame: frame)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func willMove(toSuperview newSuperview: UIView?) {
        // Configure AugmentedReality.
        let config = ARWorldTrackingConfiguration()
        sceneView.session.run(config, options: .resetTracking)
        sceneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints]
        
        timer = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(self.findSurfaces), userInfo: nil, repeats: true)

    }
    
    @objc func findSurfaces() {
        
        if hasFoundSurface {
            return
        }
        
        // Perform a hitTest to search for surfaces
        let location = CGPoint(x: sceneView.frame.width / 2, y: sceneView.frame.height / 2)
        let planes = sceneView.hitTest(location, types: ARHitTestResult.ResultType.estimatedHorizontalPlane)
        
        //Make an ARAnchor at the first surface
        let element = planes.first
        if let worldTransform = element?.worldTransform {
            let planeAnchor = ARAnchor(transform: worldTransform)
            hasFoundSurface = true
            
            // Get the X, Y and Z coordinates of the ARAnchor
            let transform = planeAnchor.transform.columns.3
            let x = CGFloat(transform.x)
            let y = CGFloat(transform.y)
            let z = CGFloat(transform.z)
            
            // make a SpriteKit scene with a Bird on it
            let skScene = SKScene(size:CGSize(width: 100, height: 100))
            skScene.backgroundColor = SKColor(white:0, alpha:0.0)
            skScene.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            
            bird = Bird(scene: skScene)
            bird.useDraw = false
            
            // make a 3D plane and use the SpriteKit scene as a material!
            let plane = SCNPlane(width:1, height:1)
            plane.materials.first?.diffuse.contents = skScene
            plane.materials.first?.isDoubleSided = true
            
            //Add plane to a node, and node to the SCNScene
            let planeNode = SCNNode(geometry: plane)
            planeNode.eulerAngles.x = -.pi / 2
            planeNode.position = SCNVector3(x, y, z)
            
            // Run the code set from initialiser.
            detectedSurface(bird)
            
            timer.invalidate()
            timer = Timer()
    
            sceneView.scene.rootNode.addChildNode(planeNode)
            

        }
        
    }
    
}
