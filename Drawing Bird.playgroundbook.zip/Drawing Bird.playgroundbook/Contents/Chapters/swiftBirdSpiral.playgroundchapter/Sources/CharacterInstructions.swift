import SpriteKit

public protocol CharacterInstructionProtocol {
    init(bird: Bird)
    
     func backslash() -> CGFloat
    
     func frontslash() -> CGFloat
    
     func dash() -> CGFloat
    
     func stroke() -> CGFloat
    
     func V() -> CGFloat
    
     func arrow() -> CGFloat
    
     func paranthesOpen() -> CGFloat
    
     func paranthesClose() -> CGFloat
    
     func space() -> CGFloat
    
     func newLine(origin: CGPoint)
    
}

public class CharacterInstructions : CharacterInstructionProtocol {
    private var bird: Bird
    public required init (bird: Bird) {
        self.bird = bird
    }
    
     func resetPosition() {
        bird.forward(-10)
        bird.rotation = 0
    }
    
     public func backslash() -> CGFloat {
        bird.rotation = 120
        let forw : CGFloat = 10
        bird.forward(forw)
        resetPosition()
        
        
        
        return FindWidth(forw, 120)
    }
    
     public func frontslash() -> CGFloat {
        bird.rotation = 60
        
        let forw : CGFloat = 10
        bird.forward(forw)
        resetPosition()
        
        bird.toggleTrail()
        
        bird.forward(FindWidth(forw, 60))
        bird.toggleTrail()
        
        
        
        return FindWidth(10, 60)
    }
    
     public func dash() -> CGFloat {
        bird.rotation = 0
        bird.forward(9)
        
        return 9
    }
    
     public func stroke() -> CGFloat {
        bird.rotation = 90
        bird.forward(10)
        resetPosition()
        
        return FindWidth(10, 90) + 0.75
    }
    
     public func V() -> CGFloat {
        let bsw = backslash()
        let fsw = frontslash()
        
        return bsw + fsw
    }
    
     public func arrow() -> CGFloat {
        let sw = space()
        bird.rotation = 150
        bird.forward(10)
        bird.rotation = 30
        bird.forward(10)
        
        resetPosition()
        bird.rotation = 150
        resetPosition()
        
        return FindWidth(10, 150) + sw
        
    }
    
     public func paranthesOpen() -> CGFloat {
        paranthes(true)
        
        return 0
    }
    
     public func paranthesClose() -> CGFloat {
        paranthes(false)
        
        return 0
    }
    
     public func space() -> CGFloat {
        bird.toggleTrail()
        bird.forward(10)
        bird.toggleTrail()
        
        return 10
    }
    
    public func newLine(origin: CGPoint) {
        bird.toggleTrail()
        
        bird.bird.position =  CGPoint(x: origin.x, y: bird.bird.position.y)
        
        bird.rotation = 0
        bird.right(90)
        bird.forward(15)
        bird.left(90)
        
        
        
        //bird.right(180)
        
        bird.toggleTrail()
    }
    
    private func paranthes(_ isOpen: Bool) {
        var forward:CGFloat = 2
        var angle:CGFloat = -20
        
        if isOpen {
            forward = -forward
            angle = -angle
        }
        bird.rotation = 0
        for _ in 1...8 {
            bird.right(angle)
            bird.forward(forward)
        }
        bird.toggleTrail()
        bird.rotation = 270
        bird.forward(12)
        bird.toggleTrail()
    }
    
    private func FindWidth(_ length:CGFloat,_ angle: CGFloat) -> CGFloat{
        let radConst = CGFloat.pi / 180
        let breidde = cos(angle * radConst) * length
        return breidde
    }
}

