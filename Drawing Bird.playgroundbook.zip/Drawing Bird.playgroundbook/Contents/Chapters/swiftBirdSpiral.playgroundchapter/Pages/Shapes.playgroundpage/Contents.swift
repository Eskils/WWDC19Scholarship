//#-hidden-code
import SpriteKit
import SceneKit
import ARKit
import PlaygroundSupport
//#-end-hidden-code
/*:
 # Bird
 
 ## Let’s draw with code🖍.
 
 The swift bird can be moved around and used to draw lots of cool stuff and shapes using code. On this page we are going to draw some simple shapes using code!
 
 We start by creating a drawing instance on the SpriteKit Scene:
 `let bird = Bird(scene: scene)`
 
 Then we can call the methods on the bird to for example fly forward 100 like so:
 `bird.forward(100)`
 or turn 90 degrees left like so:
 `bird.left(90)`
 
 ## **Instructions:**
Have a look at the code and then tap “Run My Code” and wait to see what the bird does…
 */
let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 600, height: 900))
let scene = SKScene(size: sceneView.frame.size)
scene.backgroundColor = #colorLiteral(red: 0.1176470588, green: 0.1647058824, blue: 0.2901960784, alpha: 1)
scene.anchorPoint = CGPoint(x: 0.5, y: 0.5)
sceneView.presentScene(scene)


//Initialise a bird to draw with.
let bird = Bird(scene: scene)
bird.useDraw = true

let bpos = bird.position
bird.position = CGPoint(x: bpos.x - 50 , y: bpos.y + 100)
bird.color = #colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)

//Square
for i in 1...4 {

    bird.forward(100)
    bird.left(90)
}

bird.position = CGPoint(x: bpos.x, y: bpos.y - 50)
bird.color = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)

//Circle
for i in 1...30 {
    bird.forward(12)
    bird.left(12)
}

bird.position = CGPoint(x: bpos.x - 50 , y: bpos.y - 175)
bird.rotation = 0
bird.color = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)

//Triangle
for i in 1...3 {
    
    bird.forward(100)
    bird.left(120)
}
//#-hidden-code
PlaygroundPage.current.liveView = sceneView

var objIdx = 0
func update() {
    bird.draw(objIdx)
    objIdx += 1
}

Timer.scheduledTimer(withTimeInterval: 1 / 16, repeats: true) { (timer) in
    update()
}
PlaygroundPage.current.assessmentStatus = .pass(message: "Cool! A square, a circle and a triangle. Jump on over to the next page to have a look at spirals [Next Page](@next)")
//#-end-hidden-code