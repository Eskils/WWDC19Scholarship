//#-hidden-code
import SpriteKit
import SceneKit
import ARKit
import PlaygroundSupport
//#-end-hidden-code
/*:
 # Text
 ## How about drawing text✏️!
 
 Let’s draw text with the bird. If we generate text with simple characters to draw like  `\`, `|` and `-`, it becomes easier to draw. We can achieve this by using the command-line tool `figlet` or [this website](http://patorjk.com/software/taag/#p=display&f=Doom&t=Hi).
 
 ## **Instructions:**
 
 Scroll down to the bottom of the page, and call the **`draw(string:)`** method with the string `text`. Then run the code and wait.
 */
//#-hidden-code
let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 600, height: 900))
let scene = SKScene(size: sceneView.frame.size)
scene.backgroundColor = #colorLiteral(red: 0.1176470588, green: 0.1647058824, blue: 0.2901960784, alpha: 1)
scene.anchorPoint = CGPoint(x: 0.5, y: 0.5)
sceneView.presentScene(scene)
//#-end-hidden-code
 
 //Initialise a bird to draw with.
 let bird = Bird(scene: scene)
 bird.useDraw = false
 
 func oversettTilMetode(_ str: String, _ CI : CharacterInstructions) -> CGFloat {
     switch str {
         case "\\":
            return CI.backslash()
         case "/":
            return CI.frontslash()
         case "_":
            return CI.dash()
         case "|":
            return CI.stroke()
         case "V":
            return CI.V()
         case "<":
            return CI.arrow()
         case "(":
            return CI.paranthesOpen()
         case ")":
            return CI.paranthesClose()
         default:
            return CI.space()
     }
 }
 
 func draw(string: String) {
 
     bird.toggleTrail()
     bird.forward(-200)
     bird.toggleTrail()
 
     let CI = CharacterInstructions(bird: bird)
 
     let linjer = string.split(separator: "\n")
     let hueFac = Int(360 / linjer.count)
     var origin = bird.bird.position
    
     linjer.enumerated().forEach { (linjeEnumer) in
         let (i, linje) = linjeEnumer
        
         let sat = 0.9 - (0.9 / Double(linjer.count)) * Double(i)
         var linjelengde: CGFloat = 0
        
         for karakter in linje {
             let h = CGFloat(hueFac * i)
             bird.color = UIColor(hue: h / 360, saturation: CGFloat(sat), brightness: 0.9, alpha: 1.0)
 
             linjelengde += oversettTilMetode("\(karakter)", CI) //+ bird.currentTrailwidth
 
             bird.toggleTrail()
             bird.rotation = 0
             bird.forward(5)
             linjelengde += 5
             bird.toggleTrail()
 
         }
         CI.newLine(origin: origin)
     }
    //#-hidden-code
    PlaygroundPage.current.assessmentStatus = .pass(message: "Hello! Look at that. Go to the next page to take this to a new world. [Next Page](@next)")
    //#-end-hidden-code
 }
 //#-editable-code
var text = """
    _   _ _
    | | | (_)
    | |_| |_
    |  _  | |
    | | | | |_
    \\_| |_/_(_)
 
 """
 //#-code-completion(everything, hide)
 //#-code-completion(identifier, show, draw(string:), text)
 // Call the  draw(string: text) method here:
 


 //#-end-editable-code
 
 //#-hidden-code
 PlaygroundPage.current.liveView = sceneView
 //#-end-hidden-code