//#-hidden-code
import SpriteKit
import SceneKit
import ARKit
import PlaygroundSupport
//#-end-hidden-code
/*:
 # Spirals
 ## Let’s have a go at spirals🌀.
 Spirals are shapes with an angle moving further out from it’s centre. They can be made with lots of different angles and colors!
 
 ## **Instructions:**
 
Scroll down to the bottom of the page, call the **`Spiral(angle:)`** method, type in an angle and then run the code!
 
 > Try some angles like 60, 90, 120 and 170! What results are you getting then?
 */
//#-hidden-code
let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 600, height: 900))
let scene = SKScene(size: sceneView.frame.size)
scene.backgroundColor = #colorLiteral(red: 0.1176470588, green: 0.1647058824, blue: 0.2901960784, alpha: 1)
scene.anchorPoint = CGPoint(x: 0.5, y: 0.5)
sceneView.presentScene(scene)
//#-end-hidden-code

//Initialise a bird to draw with.
let bird = Bird(scene: scene)
bird.useDraw = false

var length: CGFloat = 0
func Spiral(angle: CGFloat) {
 
    bird.forward(length)
    bird.left(angle)
 
    let hue = length.truncatingRemainder(dividingBy: 360)
    bird.color = UIColor(hue:hue / 360, saturation: 1.0, brightness: 1.0, alpha: 1.0)
 
    length += 1 / 30 * angle
    
    //#-hidden-code
    PlaygroundPage.current.assessmentStatus = .pass(message: "Whoah! That spiral looks amazing! Head on over to the next page to learn more about what the bird can draw. [Next Page](@next)")
    //#-end-hidden-code
}

 func update() {
    //#-code-completion(everything, hide)
    //#-code-completion(identifier, show, Spiral(angle:))
    //#-editable-code Tap here to write some code!
    // Call the Spiral(angle:) method here:
    
    
    
    //#-end-editable-code
 }
//#-hidden-code
PlaygroundPage.current.liveView = sceneView

//Haha, quick and dirty way to make an update() method😆. Did not want to make a SKScene class.
Timer.scheduledTimer(withTimeInterval: 1 / 16, repeats: true) { (timer) in
    update()
}

//#-end-hidden-code