//#-hidden-code
import SpriteKit
import SceneKit
import ARKit
import PlaygroundSupport
//#-end-hidden-code
/*:
 # Augmented Reality
 ## Drawing on tables and floors🤘.
 Using the ARKit framework, we can make the bird draw on surfaces in the real world. Let‘s try it by drawing a spiral.
 
 ## **Instructions:**
 
Scroll down to the bottom of the page, call the **`Spiral(angle:)`** method, type in an angle and then run the code!
 */
//#-hidden-code
 if #available(iOSApplicationExtension 11.0, *) {
 print("isAvailible")
//#-end-hidden-code

    var length: CGFloat = 0
    var bird: Bird?
    
    func Spiral(angle: CGFloat) {
        
        bird?.forward(length)
        bird?.left(angle)
        
        let hue = length.truncatingRemainder(dividingBy: 360)
        bird?.color = UIColor(hue:hue / 360, saturation: 1.0, brightness: 1.0, alpha: 1.0)
        
        length += 1 / 30 * angle
    }
    
    var arWorld = ARBirdWorld { (aBird) in
        length = 0.0
        bird = aBird
        for i in 0...50 {
            //#-code-completion(everything, hide)
            //#-code-completion(identifier, show, Spiral(angle:))
            //#-editable-code Tap here to write some code!
            // Call the Spiral(angle:) method here:
            
            
            
            //#-end-editable-code
        }
    }
//#-hidden-code
 PlaygroundPage.current.liveView = arWorld.sceneView
 }
//#-end-hidden-code